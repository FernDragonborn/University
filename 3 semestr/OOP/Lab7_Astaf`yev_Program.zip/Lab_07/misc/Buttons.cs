﻿namespace Lab_07.misc;
internal static class Buttons
{
    //work menu
    internal const string BtnWorkBarista = "Бариста";
    internal const string BtnWorkTutor = "Репетиторство";
    internal const string BtnWorkFreelance = "Фріланс";
    //leisure menu
    internal const string BtnLeisureLake = "Міське озеро";
    internal const string BtnLeisureGym = "Спортзал";
    internal const string BtnLeisureFriend = "Погуляти з другом";
}
