﻿namespace Lab_07.enums
{
    public enum Menus
    {
        Start,
        GetName,
        Day,
        Work,
        Lesuire,
        Activity,
        Relocation,
        Event,
    }
}
