﻿namespace Lab_07.enums
{
    public enum State
    {
        MainMenu,
        GetName,
        ChoosePlayer,
        Interaction,
        CustomInteraction,
        DeletePlayer,
        SaveCollection,
        ReadCollection,
    }
}
